package com.reserve;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

public class RoomServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static List<Room> rooms = new ArrayList<>();

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String roomNumber = request.getParameter("roomNumber");
        String category = request.getParameter("category");
        
        // Add more parameters as needed

        // Create a new Room object
        Room room = new Room(roomNumber, category);
        
        // Add the room to the list (for demonstration purposes)
        rooms.add(room);

        // Redirect to roomAdded.jsp
        response.sendRedirect("roomAdded.jsp");
    }
}
