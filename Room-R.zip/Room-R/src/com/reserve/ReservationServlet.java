package com.reserve;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ReservationServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String category = request.getParameter("category");
        int duration = Integer.parseInt(request.getParameter("duration"));
        
        // Check for room availability and perform reservation logic
        boolean isRoomAvailable = checkRoomAvailability(category, duration);
        
        if (isRoomAvailable) {
            // Perform reservation logic here (e.g., update database, set reservation status)
            // Redirect to reservation confirmation page
            response.sendRedirect("reservationConfirmation.jsp");
        } else {
            // Handle case where room is not available
            // Redirect to an error page or back to welcome.jsp with a message
            response.sendRedirect("welcome.jsp?error=unavailable");
        }
    }

    // Replace this method with your actual availability checking logic
    private boolean checkRoomAvailability(String category, int duration) {
        // Simulated logic: Assume room is available if category is "Standard" and duration is less than 7
        return category.equals("Standard") && duration < 7;
    }
}
